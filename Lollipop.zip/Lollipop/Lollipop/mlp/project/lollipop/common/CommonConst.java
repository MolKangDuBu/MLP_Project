package mlp.project.lollipop.common;


public class CommonConst {
	
	 
	public static final String FilePath="upload";
	public static final String sourceUrl = "http://127.0.0.1:8080/lollipop";
}
