package mlp.project.lollipop.NOTICE;

public interface NoticeService {

}
