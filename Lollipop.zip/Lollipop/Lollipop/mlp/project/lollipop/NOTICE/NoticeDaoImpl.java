package mlp.project.lollipop.NOTICE;

import org.springframework.stereotype.Repository;

@Repository("noticeDao")
public class NoticeDaoImpl implements NoticeDao{

}
