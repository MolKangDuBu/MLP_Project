package mlp.project.lollipop.MARK;

import org.springframework.stereotype.Repository;

@Repository("markDao")
public class MarkDaoImpl implements MarkDao{

}
