package mlp.project.lollipop.MARK;

public interface MarkDao {

}
