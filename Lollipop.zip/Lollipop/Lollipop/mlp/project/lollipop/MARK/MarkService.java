package mlp.project.lollipop.MARK;


public interface MarkService {

}
