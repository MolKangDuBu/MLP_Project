package mlp.project.lollipop.QNA;

public interface QnaService {

}
