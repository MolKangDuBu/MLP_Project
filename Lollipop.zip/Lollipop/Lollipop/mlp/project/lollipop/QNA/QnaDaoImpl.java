package mlp.project.lollipop.QNA;

import org.springframework.stereotype.Repository;

@Repository("qnaDao")
public class QnaDaoImpl implements QnaDao{

}
