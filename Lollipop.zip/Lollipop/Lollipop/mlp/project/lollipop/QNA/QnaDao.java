package mlp.project.lollipop.QNA;

public interface QnaDao {

}
