package mlp.project.lollipop.USER;

public class UserDto {
	private int user_key;
	private String user_id;
	private String user_password;
	private String user_name;
	private String user_mail;
	private String user_phone;
	private String user_wdate;
	private char user_active;
	private char user_admin;
	
	
	public int getUser_key() {
		return user_key;
	}
	public void setUser_key(int user_key) {
		this.user_key = user_key;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_mail() {
		return user_mail;
	}
	public void setUser_mail(String user_mail) {
		this.user_mail = user_mail;
	}
	public String getUser_phone() {
		return user_phone;
	}
	public void setUser_phone(String user_phone) {
		this.user_phone = user_phone;
	}
	public String getUser_wdate() {
		return user_wdate;
	}
	public void setUser_wdate(String user_wdate) {
		this.user_wdate = user_wdate;
	}
	public char getUser_active() {
		return user_active;
	}
	public void setUser_active(char user_active) {
		this.user_active = user_active;
	}
	public char getUser_admin() {
		return user_admin;
	}
	public void setUser_admin(char user_admin) {
		this.user_admin = user_admin;
	}
	
	
	
}
